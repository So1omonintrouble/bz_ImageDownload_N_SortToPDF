# -*- coding =utf-8 -*-
# @time : 2021/5/4 20:14
# @Author : Rov
# @File : test.py
# @Software : PyCharm
import requests

count = 2120901
while True:
    r = requests.get('https://www.comap-math.com/mcm/2021Certs/' + str(count) + '.pdf')
    r1 = requests.get('https://www.comap-math.com/mcm/2021Certs/' + str(count - 1) + '.pdf')
    temp = count
    if r.reason == 'OK' or r1.reason == 'OK':
        count += 100
    if temp != count:
        print(count)
    r.close()
    r1.close()